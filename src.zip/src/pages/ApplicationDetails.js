import React from 'react'

const ApplicationSummary = () => {
  return (
    <div>ApplicationSummary</div>
  )
}

export default ApplicationSummary